package com.amazonweb.runner;

import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@CucumberOptions(features = "classpath:FeatureFiles/HomePage.feature", glue = "stepDefinitions", plugin = {
		"json:target/jsonReports/cucumber-report.json", "html:target/htmlreport.html" })

@RunWith(Cucumber.class)
public class TestRunner {

}
