package stepDefinitions;

import com.amazonweb.base.Base;
import com.amazonweb.utils.ConfigurationFileReader;

import io.cucumber.java.After;
import io.cucumber.java.Before;

public class Hooks {

	@Before
	public static void startUp() {
		Base.reader = new ConfigurationFileReader();
		Base.initializeBrowser();
	}

	@After
	public static void tearDown() {
		Base.quitBrowser();

	}
}
