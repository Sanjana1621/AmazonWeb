package com.amazonweb.utils;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

public interface ExcelFileReader {

	public static String getCellData(String key) throws InvalidFormatException, IOException {
		FileInputStream fis = null;
		Workbook wb = null;
		Sheet sheetName = null;
		String value = "";
		try {

			fis = new FileInputStream(
					"C:\\Users\\User\\eclipse-workspace\\amazonweb\\src\\main\\resources\\testdata\\AmazonTestData.xlsx");
			wb = WorkbookFactory.create(fis);
			sheetName = wb.getSheet("TestData");
			int noOfRows = sheetName.getPhysicalNumberOfRows();
			for (int i = 1; i < noOfRows; i++) {
				Row r = sheetName.getRow(i);
				if ((r.getCell(0)).getStringCellValue().equalsIgnoreCase(key)) {
					value = r.getCell(1).getStringCellValue();
				}
			}
			return value;
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			fis.close();
		}
		return value;
	}
}
